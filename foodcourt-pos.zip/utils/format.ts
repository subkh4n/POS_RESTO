
export const fmt = (n: number) => new Intl.NumberFormat('id-ID').format(n);

export const fmtCurrency = (n: number) => 
  new Intl.NumberFormat('id-ID', { 
    style: 'currency', 
    currency: 'IDR', 
    minimumFractionDigits: 0 
  }).format(n);

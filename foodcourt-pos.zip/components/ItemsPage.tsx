
import React, { useState, useRef } from 'react';
import { 
  Plus, 
  Image as ImageIcon, 
  Save, 
  X, 
  Loader2,
  Search,
  Edit2,
  Trash2,
  AlertTriangle,
  ToggleLeft,
  ToggleRight,
  Package2,
  Briefcase,
  Zap
} from 'lucide-react';
import { 
  addProduct, 
  uploadImage, 
  updateProduct, 
  deleteProduct 
} from '../services/api';
import { Product } from '../types';

type ItemsSubView = 'list' | 'add';

interface ItemsPageProps {
  products: Product[];
  categories: {name: string}[];
  onRefresh: () => void;
}

const ItemsPage: React.FC<ItemsPageProps> = ({ products, categories, onRefresh }) => {
  const [subView, setSubView] = useState<ItemsSubView>('list');
  const [isSaving, setIsSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [addStockAmount, setAddStockAmount] = useState<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [toast, setToast] = useState<{show: boolean, msg: string, type: 'success' | 'error'}>({
    show: false, msg: '', type: 'success'
  });

  const [formData, setFormData] = useState({
    name: '',
    category: '',
    stock: 0,
    stockType: 'STOK_FISIK' as 'STOK_FISIK' | 'NON_STOK' | 'JASA',
    price: 0,
    sku: '',
    available: true,
    image: '',
    preview: ''
  });

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ show: true, msg, type });
    setTimeout(() => setToast(prev => ({ ...prev, show: false })), 3000);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async (event) => {
        const base64 = event.target?.result as string;
        setFormData(prev => ({ ...prev, preview: base64 }));
        const result = await uploadImage(base64, file.name);
        if (result.success && result.url) {
          setFormData(prev => ({ ...prev, image: result.url! }));
          showToast("Gambar berhasil diunggah");
        }
        setIsUploading(false);
      };
    } catch (err) {
      showToast("Gagal memproses gambar", "error");
      setIsUploading(false);
    }
  };

  const handleEdit = (p: Product) => {
    setEditingId(p.id);
    setAddStockAmount(0);
    setFormData({
      name: p.name,
      category: p.category,
      stock: p.stock,
      stockType: p.stockType || 'STOK_FISIK',
      price: p.price,
      sku: p.id,
      available: p.available,
      image: p.image,
      preview: p.image
    });
    setSubView('add');
  };

  const handleSave = async () => {
    if (!formData.name) { showToast("Nama produk wajib diisi", "error"); return; }
    setIsSaving(true);
    
    const finalStock = formData.stockType === 'STOK_FISIK' 
      ? formData.stock + addStockAmount 
      : 0;

    const payload: Partial<Product> = {
      id: editingId || formData.sku || `ITEM-${Math.floor(Math.random() * 100000)}`,
      name: formData.name,
      category: formData.category,
      stock: finalStock,
      stockType: formData.stockType,
      price: formData.price,
      available: formData.available,
      image: formData.image
    };

    try {
      const result = editingId ? await updateProduct(payload) : await addProduct(payload);
      if (result.success) {
        showToast("Produk berhasil disimpan");
        setSubView('list');
        onRefresh();
      } else {
        showToast(result.message || "Gagal menyimpan", "error");
      }
    } catch (e) {
      showToast("Kesalahan jaringan", "error");
    } finally {
      setIsSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!productToDelete) return;
    setDeletingId(productToDelete.id);
    try {
      const result = await deleteProduct(productToDelete.id);
      if (result.success) {
        showToast("Produk berhasil dihapus");
        setShowDeleteModal(false);
        setProductToDelete(null);
        onRefresh();
      }
    } catch (err) {
      showToast("Gagal menghapus data", "error");
    } finally {
      setDeletingId(null);
    }
  };

  const renderListView = () => (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 px-2">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Inventori Produk</h1>
          <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest mt-1">Manajemen Menu & Stok</p>
        </div>
        <button 
          onClick={() => {
            setEditingId(null);
            setAddStockAmount(0);
            setFormData({ name: '', category: categories[0]?.name || 'Food', stock: 0, stockType: 'STOK_FISIK', price: 0, sku: '', available: true, image: '', preview: '' });
            setSubView('add');
          }}
          className="bg-slate-900 text-white px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center gap-2 hover:scale-105 transition-all"
        >
          <Plus size={18} /> Tambah Menu
        </button>
      </div>

      <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm mb-6 flex gap-4">
          <div className="relative flex-1">
            <input 
              type="text" 
              placeholder="Cari menu atau SKU..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-50 border border-transparent rounded-2xl py-3 pl-10 pr-4 text-sm font-medium focus:ring-2 focus:ring-slate-900 focus:bg-white outline-none transition-all"
            />
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          </div>
          <button onClick={onRefresh} className="p-3 bg-gray-50 text-gray-500 rounded-2xl hover:bg-gray-100 transition-all">
            <Loader2 size={18} className={isSaving ? 'animate-spin' : ''} />
          </button>
      </div>

      <div className="bg-white rounded-[40px] border border-gray-100 shadow-sm overflow-hidden mb-12">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50/50 text-gray-400 text-[10px] uppercase tracking-widest font-black">
                <th className="px-8 py-6">Item</th>
                <th className="px-8 py-6">Kategori</th>
                <th className="px-8 py-6">Sisa Stok / Status</th>
                <th className="px-8 py-6">Metode</th>
                <th className="px-8 py-6 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {products.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase())).map((p, idx) => {
                const isDonation = p.category.toLowerCase() === 'donasi';
                const isPhysical = p.stockType === 'STOK_FISIK';
                
                return (
                  <tr key={p.id || idx} className={`hover:bg-gray-50/30 transition-colors ${!p.available ? 'opacity-60 grayscale' : ''}`}>
                    <td className="px-8 py-5 flex items-center gap-4">
                      <img src={p.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=500&q=80'} className="w-12 h-12 rounded-2xl object-cover bg-gray-100" />
                      <div>
                        <p className="text-sm font-black text-slate-800 leading-none mb-1">{p.name}</p>
                        <p className="text-[9px] text-gray-400 font-bold uppercase">SKU: {p.id}</p>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider ${isDonation ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 text-slate-500'}`}>{p.category}</span>
                    </td>
                    <td className="px-8 py-5">
                       {isPhysical ? (
                         <div className="flex flex-col">
                            <span className={`text-xs font-black ${p.stock <= 0 ? 'text-rose-600' : p.stock < 10 ? 'text-amber-500' : 'text-emerald-600'}`}>
                              Sisa: {p.stock} pcs
                            </span>
                            <div className="w-24 h-1.5 bg-gray-100 rounded-full mt-1.5 overflow-hidden">
                               <div className={`h-full ${p.stock <= 0 ? 'bg-rose-500' : p.stock < 10 ? 'bg-amber-500' : 'bg-emerald-500'}`} style={{ width: `${Math.min(p.stock, 100)}%` }} />
                            </div>
                         </div>
                       ) : (
                         <div className="flex items-center gap-2">
                           <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${p.available ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-rose-50 text-rose-600 border-rose-200'}`}>
                             {p.available ? '● ON (MELAYANI)' : '○ OFF (TUTUP)'}
                           </span>
                         </div>
                       )}
                    </td>
                    <td className="px-8 py-5">
                       <div className="flex items-center gap-2">
                          {p.stockType === 'STOK_FISIK' ? <Package2 size={14} className="text-emerald-500" /> : p.stockType === 'JASA' ? <Briefcase size={14} className="text-blue-500" /> : <Zap size={14} className="text-amber-500" />}
                          <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                            {p.stockType.replace('_', ' ')}
                          </p>
                       </div>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center justify-center gap-2">
                        <button onClick={() => handleEdit(p)} className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"><Edit2 size={16} /></button>
                        <button onClick={() => {setProductToDelete(p); setShowDeleteModal(true);}} className="p-2 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all"><Trash2 size={16} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderAddView = () => {
    const isDonation = formData.category.toLowerCase() === 'donasi';
    return (
      <div className="animate-in slide-in-from-right-8 duration-500 max-w-4xl mx-auto pb-20">
        <div className="flex items-center justify-between mb-8 px-4">
          <div>
            <h1 className="text-2xl font-black text-slate-900">{editingId ? 'Edit Item' : 'Tambah Menu'}</h1>
            <p className="text-gray-400 text-[10px] font-bold uppercase mt-1">Konfigurasi produk</p>
          </div>
          <button onClick={() => setSubView('list')} className="p-3 bg-white border border-gray-100 text-gray-400 rounded-2xl"><X size={20} /></button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
             <div className="bg-white p-6 rounded-[40px] border border-gray-100 shadow-sm flex flex-col items-center">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full aspect-square rounded-[32px] border-2 border-dashed border-gray-100 bg-gray-50 flex flex-col items-center justify-center cursor-pointer overflow-hidden relative"
                >
                  {formData.preview ? <img src={formData.preview} className="w-full h-full object-cover" /> : <ImageIcon size={48} className="text-gray-200" />}
                  {isUploading && <div className="absolute inset-0 bg-slate-900/40 flex items-center justify-center"><Loader2 className="animate-spin text-white" /></div>}
                  <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
                </div>

                <div className="w-full mt-6 p-6 bg-gray-50 rounded-[32px] border border-gray-100">
                   <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-black uppercase text-gray-400">Status Penjualan</span>
                      <span className={`text-[10px] font-black uppercase ${formData.available ? 'text-emerald-500' : 'text-rose-500'}`}>{formData.available ? 'Aktif' : 'Tutup'}</span>
                   </div>
                   <button 
                    onClick={() => setFormData({...formData, available: !formData.available})}
                    className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl transition-all ${formData.available ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-100' : 'bg-gray-200 text-gray-500'}`}
                   >
                     <span className="text-xs font-black uppercase">Bisa Order</span>
                     {formData.available ? <ToggleRight size={28} /> : <ToggleLeft size={28} />}
                   </button>
                </div>
             </div>
          </div>

          <div className="lg:col-span-2 space-y-6">
             <div className="bg-white p-8 md:p-10 rounded-[40px] border border-gray-100 shadow-sm space-y-6">
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase block mb-2 px-1">Nama Produk</label>
                  <input type="text" className="w-full bg-gray-50 border-transparent rounded-2xl py-4 px-6 text-sm font-bold outline-none focus:bg-white focus:ring-2 focus:ring-slate-900 transition-all" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-[10px] font-black text-gray-400 uppercase block mb-2 px-1">Kategori</label>
                    <select className="w-full bg-gray-50 border-transparent rounded-2xl py-4 px-6 text-sm font-bold outline-none" value={formData.category} onChange={(e) => setFormData({...formData, category: e.target.value})}>
                      {categories.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
                    </select>
                  </div>

                  {!isDonation && (
                    <div>
                      <label className="text-[10px] font-black text-gray-400 uppercase block mb-2 px-1">Harga Satuan (Rp)</label>
                      <input type="number" className="w-full bg-gray-50 border-transparent rounded-2xl py-4 px-6 text-sm font-black outline-none" value={formData.price} onChange={(e) => setFormData({...formData, price: parseInt(e.target.value) || 0})} />
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-3">
                   {[
                     { id: 'STOK_FISIK', icon: Package2 },
                     { id: 'NON_STOK', icon: Zap },
                     { id: 'JASA', icon: Briefcase }
                   ].map(st => (
                     <button key={st.id} onClick={() => setFormData({...formData, stockType: st.id as any})} className={`py-4 rounded-2xl text-[10px] font-black uppercase border transition-all flex flex-col items-center gap-2 ${formData.stockType === st.id ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-gray-400 border-gray-100'}`}>
                        <st.icon size={18} />
                        {st.id.replace('_', ' ')}
                     </button>
                   ))}
                </div>

                {formData.stockType === 'STOK_FISIK' && (
                  <div className="grid grid-cols-2 gap-4">
                     <div className="bg-gray-50 p-4 rounded-2xl">
                       <label className="text-[9px] font-black text-gray-400 uppercase block">Stok Sisa</label>
                       <span className="font-black text-lg">{formData.stock}</span>
                     </div>
                     <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
                       <label className="text-[9px] font-black text-emerald-600 uppercase block">Tambah Stok</label>
                       <input type="number" className="bg-transparent border-none p-0 text-lg font-black text-emerald-700 outline-none w-full" placeholder="0" value={addStockAmount || ''} onChange={(e) => setAddStockAmount(parseInt(e.target.value) || 0)} />
                     </div>
                  </div>
                )}

                <div className="pt-6 flex gap-4">
                  <button onClick={() => setSubView('list')} className="flex-1 py-5 bg-gray-50 text-gray-400 rounded-2xl font-black text-xs uppercase">Batal</button>
                  <button onClick={handleSave} disabled={isSaving || isUploading} className="flex-[2] py-5 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase shadow-2xl flex items-center justify-center gap-2">
                    {isSaving ? <Loader2 className="animate-spin" /> : <Save size={18} />} Simpan Produk
                  </button>
                </div>
             </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 bg-gray-50 h-screen overflow-y-auto custom-scroll p-4 lg:p-8 relative">
      {showDeleteModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-[40px] shadow-2xl max-w-sm w-full p-10 text-center animate-in zoom-in-95">
            <div className="w-20 h-20 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-6"><AlertTriangle size={40} /></div>
            <h3 className="text-xl font-black text-slate-900 mb-2">Hapus Produk?</h3>
            <p className="text-xs text-gray-400 mb-8">Tindakan ini permanen. Produk <span className="text-slate-900 font-bold">"{productToDelete?.name}"</span> akan dihapus.</p>
            <div className="flex gap-4">
              <button onClick={() => setShowDeleteModal(false)} className="flex-1 py-4 bg-gray-50 text-gray-500 rounded-2xl font-black text-[10px] uppercase">Batal</button>
              <button onClick={confirmDelete} className="flex-1 py-4 bg-rose-600 text-white rounded-2xl font-black text-[10px] uppercase shadow-lg shadow-rose-100">Hapus</button>
            </div>
          </div>
        </div>
      )}
      {toast.show && (
        <div className={`fixed bottom-8 right-8 z-[100] flex items-center gap-3 px-6 py-4 rounded-2xl shadow-2xl animate-in slide-in-from-bottom-10 ${toast.type === 'success' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}>
          <span className="text-[10px] font-black uppercase tracking-widest">{toast.msg}</span>
        </div>
      )}
      {subView === 'list' ? renderListView() : renderAddView()}
    </div>
  );
};

export default ItemsPage;


import React from 'react';
import { Product } from '../types';
import { ShoppingCart, Heart, Package2, Sparkles, Briefcase, Zap } from 'lucide-react';
import { fmtCurrency } from '../utils/format';

interface ProductCardProps {
  product: Product;
  onAdd: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAdd }) => {
  const isFlexible = product.category.toLowerCase() === 'donasi' || product.priceType === 'FLEXIBLE';
  const isPhysical = product.stockType === 'STOK_FISIK';
  const isNonStock = product.stockType === 'NON_STOK';
  const isJasa = product.stockType === 'JASA';
  
  // Jika stok fisik habis, atau available disetting OFF, maka produk tidak bisa diorder
  const isDisabled = (isPhysical && product.stock <= 0) || !product.available;

  return (
    <div className={`bg-white rounded-2xl p-3 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group h-full border ${isFlexible ? 'border-amber-200 bg-amber-50/30' : 'border-gray-50'} ${isDisabled ? 'opacity-75' : ''}`}>
      <div className="relative mb-2 overflow-hidden rounded-xl h-28 flex-shrink-0">
        <img 
          src={product.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=500&q=80'} 
          alt={product.name}
          className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 ${isDisabled ? 'grayscale' : ''}`} 
        />
        
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {isFlexible ? (
            <span className="bg-amber-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-lg flex items-center gap-1">
              <Sparkles size={8} fill="currentColor" /> OPEN PRICE
            </span>
          ) : isPhysical ? (
             <span className={`text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-lg border ${product.stock <= 0 ? 'bg-rose-500 border-rose-400' : 'bg-emerald-500 border-emerald-400'}`}>
               SISA: {product.stock}
             </span>
          ) : (
            <span className={`text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-lg border ${product.available ? 'bg-blue-500 border-blue-400' : 'bg-gray-400 border-gray-300'}`}>
              {product.available ? '● ON' : '○ OFF'}
            </span>
          )}
        </div>

        {isDisabled && (
          <div className="absolute inset-0 bg-black/40 backdrop-blur-[1px] flex items-center justify-center">
            <span className="bg-gray-800/90 text-white text-[10px] px-3 py-1 rounded-full uppercase font-black tracking-widest border border-white/20">
              {product.stock <= 0 && isPhysical ? 'Habis' : 'Tutup'}
            </span>
          </div>
        )}
      </div>

      <div className="flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-bold text-gray-800 text-[11px] leading-tight line-clamp-2 pr-1">{product.name}</h3>
        </div>
        <p className={`${isFlexible ? 'text-amber-600' : 'text-emerald-600'} font-black text-xs mb-3`}>
          {isFlexible ? "Input Harga" : fmtCurrency(product.price)}
        </p>
        
        <button
          onClick={() => onAdd(product)}
          disabled={isDisabled}
          className={`mt-auto flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all
            ${!isDisabled
              ? isFlexible 
                ? 'bg-amber-500 text-white hover:bg-amber-600 hover:shadow-lg shadow-amber-100' 
                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-500 hover:text-white hover:shadow-lg shadow-emerald-100' 
              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
            }`}
        >
          {isFlexible ? <Heart size={12} fill="currentColor" /> : <ShoppingCart size={12} />}
          {isFlexible ? 'Donasi' : 'Tambah'}
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
